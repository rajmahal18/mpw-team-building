import { notFound, redirect } from "next/navigation";
import { getCurrentUser } from "@/server/auth/session";
import { requireEventCapability } from "@/server/permissions/capabilities";
import { getPrisma } from "@/lib/prisma";
import { EventBrandingConfigSchema, EventConfigSchema } from "@/schemas/event";
import { TechnicalLimits } from "@/schemas/shared";
import { formatDateTimeLocal } from "@/lib/timezone";
import { addParticipant, archiveTeam, assignParticipantTeam, bulkCreateTeams, createTeam, updateEventBranding, updateEventConfiguration, updateEventDetails, updateTeam } from "./actions";

export default async function EventSetupPage({ params }: { params: Promise<{ eventId: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const { eventId } = await params;
  await requireEventCapability(user.id, eventId, "event.configure");
  const event = await getPrisma().event.findUnique({
    where: { id: eventId },
    include: {
      teams: { orderBy: { createdAt: "asc" } },
      participants: { include: { person: true, teamMemberships: { where: { status: "ACTIVE" }, include: { team: true } } }, orderBy: { createdAt: "asc" } },
    },
  });
  if (!event) notFound();
  const config = EventConfigSchema.parse(event.configJson);
  const branding = EventBrandingConfigSchema.parse(event.brandingJson ?? {});
  const activeTeams = event.teams.filter((team) => team.status === "ACTIVE");

  return <main>
    <div className="page-heading"><div><h1>Event setup</h1><p className="muted">Configure the event as data. Nothing here is tied to one year, team count, game, or MPW activity format.</p></div></div>

    <section className="card"><h2>Event identity & schedule</h2><form action={updateEventDetails} className="grid">
      <input type="hidden" name="eventId" value={event.id}/>
      <label>Event name<input name="name" defaultValue={event.name} required/></label>
      <label>Short name<input name="shortName" defaultValue={event.shortName ?? ""}/></label>
      <label>URL slug<input name="slug" defaultValue={event.slug} pattern="[a-z0-9_-]+" required/></label>
      <label>IANA timezone<input name="timezone" defaultValue={event.timezone} required/></label>
      <label>Starts<input name="startsAt" type="datetime-local" defaultValue={formatDateTimeLocal(event.startsAt, event.timezone)}/></label>
      <label>Ends<input name="endsAt" type="datetime-local" defaultValue={formatDateTimeLocal(event.endsAt, event.timezone)}/></label>
      <div className="form-actions"><button>Save event details</button></div>
    </form></section>

    <section className="card"><h2>Language & participation rules</h2><form action={updateEventConfiguration} className="stack">
      <input type="hidden" name="eventId" value={event.id}/>
      <div className="grid">
        <label>Team label<input name="termTeam" defaultValue={config.terminology.team} required/></label>
        <label>Participant label<input name="termParticipant" defaultValue={config.terminology.participant} required/></label>
        <label>Station label<input name="termStation" defaultValue={config.terminology.station} required/></label>
        <label>Marshal label<input name="termMarshal" defaultValue={config.terminology.marshal} required/></label>
        <label>Points label<input name="termPoints" defaultValue={config.terminology.points} required/></label>
        <label>Account requirement<select name="accountRequirement" defaultValue={config.participation.accountRequirement}><option>NONE</option><option>OPTIONAL</option><option>REQUIRED</option></select></label>
        <label>Participant device mode<select name="deviceMode" defaultValue={config.participation.deviceMode}><option>INDIVIDUAL</option><option>SHARED_TEAM</option><option>EITHER</option></select></label>
      </div>
      <div className="check-grid">
        <label className="check"><input type="checkbox" name="allowLateJoin" defaultChecked={config.participation.allowLateJoin}/>Allow late joining</label>
        <label className="check"><input type="checkbox" name="leaderboardEnabled" defaultChecked={config.leaderboard.enabled}/>Leaderboard enabled</label>
        <label className="check"><input type="checkbox" name="hideExactScores" defaultChecked={config.leaderboard.hideExactScores}/>Hide exact leaderboard scores</label>
        <label className="check"><input type="checkbox" name="enforceSchedule" defaultChecked={config.timing.enforceSchedule}/>Enforce event schedule</label>
        <label className="check"><input type="checkbox" name="timingAllowLateJoin" defaultChecked={config.timing.allowLateJoin}/>Schedule allows late join</label>
      </div>
      <div className="grid">
        <label>Leaderboard visibility<select name="leaderboardVisibility" defaultValue={config.leaderboard.visibility}><option>PUBLIC</option><option>PARTICIPANTS</option><option>STAFF_ONLY</option></select></label>
        <label>Leaderboard timing<select name="leaderboardMode" defaultValue={config.leaderboard.mode}><option>LIVE</option><option>DELAYED</option><option>FINAL_ONLY</option></select></label>
        <label>Show top N only<input name="topOnly" type="number" min="1" defaultValue={config.leaderboard.topOnly ?? ""}/></label>
        <label>Event visibility<select name="eventVisibility" defaultValue={config.privacy.eventVisibility}><option>PUBLIC</option><option>PRIVATE_LINK</option><option>INVITE_ONLY</option></select></label>
        <label>Participant names<select name="participantNameVisibility" defaultValue={config.privacy.participantNameVisibility}><option>PUBLIC</option><option>EVENT_ONLY</option><option>STAFF_ONLY</option></select></label>
        <label>Media visibility<select name="mediaVisibility" defaultValue={config.privacy.mediaVisibility}><option>PUBLIC</option><option>EVENT_ONLY</option><option>STAFF_ONLY</option><option>DISABLED</option></select></label>
        <label>Retention days<input name="retentionDays" type="number" min="1" max="3650" defaultValue={config.privacy.retentionDays ?? ""}/></label>
        <label>Early check-in minutes<input name="allowEarlyCheckInMinutes" type="number" min="0" max="1440" defaultValue={config.timing.allowEarlyCheckInMinutes}/></label>
      </div>
      <div className="form-actions"><button>Save event rules</button></div>
    </form></section>

    <section className="card"><h2>Event appearance</h2><p className="muted">Participant and public views consume these theme tokens. Keep contrast high enough for outdoor and projector use.</p><form action={updateEventBranding} className="grid">
      <input type="hidden" name="eventId" value={event.id}/>
      <label>Logo asset ID<input name="logoAssetId" defaultValue={branding.logoAssetId ?? ""}/></label>
      <label>Cover asset ID<input name="coverAssetId" defaultValue={branding.coverAssetId ?? ""}/></label>
      <label>Team color usage<select name="teamColorUsage" defaultValue={branding.teamColorUsage ?? "ACCENT"}><option>NONE</option><option>ACCENT</option><option>PROMINENT</option></select></label>
      <label>Accent token<input name="accent" defaultValue={branding.themeTokens?.accent ?? ""} placeholder="#... or semantic token"/></label>
      <label>Background token<input name="background" defaultValue={branding.themeTokens?.background ?? ""}/></label>
      <label>Surface token<input name="surface" defaultValue={branding.themeTokens?.surface ?? ""}/></label>
      <label>Text token<input name="text" defaultValue={branding.themeTokens?.text ?? ""}/></label>
      <div className="form-actions"><button>Save branding config</button></div>
    </form></section>

    <section className="card"><div className="section-heading"><div><h2>Teams</h2><p className="muted">Current active teams: {activeTeams.length}. There is no fixed team count or team size.</p></div></div>
      <details><summary>Add one team</summary><form action={createTeam} className="grid details-body"><input type="hidden" name="eventId" value={event.id}/><label>Name<input name="name" required/></label><label>Machine key<input name="machineKey" pattern="[a-z0-9_-]+" required/></label><label>Abbreviation<input name="abbreviation"/></label><label>Color token<input name="colorToken"/></label><label>Logo asset ID<input name="logoAssetId"/></label><label>Optional join code<input name="teamCode" minLength={4}/></label><div className="form-actions"><button>Add team</button></div></form></details>
      <details><summary>Bulk-create numbered teams</summary><form action={bulkCreateTeams} className="grid details-body"><input type="hidden" name="eventId" value={event.id}/><label>How many?<input name="count" type="number" min="1" max={TechnicalLimits.maxTeamsPerBulkOperation} required/></label><label>Name prefix<input name="namePrefix" defaultValue={config.terminology.team}/></label><label>Machine-key prefix<input name="keyPrefix" defaultValue="team" pattern="[a-z0-9_-]+"/></label><label>Start number<input name="startNumber" type="number" min="0" defaultValue="1"/></label><div className="form-actions"><button>Create teams</button></div></form></details>
      <div className="list-stack">{event.teams.map((team) => <details className="subcard" key={team.id}><summary><strong>{team.name}</strong> <span className="muted">· {team.machineKey} · {team.status}</span></summary><form action={updateTeam} className="grid details-body"><input type="hidden" name="eventId" value={event.id}/><input type="hidden" name="teamId" value={team.id}/><label>Name<input name="name" defaultValue={team.name} required/></label><label>Abbreviation<input name="abbreviation" defaultValue={team.abbreviation ?? ""}/></label><label>Color token<input name="colorToken" defaultValue={team.colorToken ?? ""}/></label><label>Logo asset ID<input name="logoAssetId" defaultValue={team.logoAssetId ?? ""}/></label><label>Replace join code<input name="teamCode" minLength={4} placeholder="Leave blank to keep existing"/></label><div className="form-actions"><button>Save team</button></div></form>{team.status === "ACTIVE" && <form action={archiveTeam} className="details-body"><input type="hidden" name="eventId" value={event.id}/><input type="hidden" name="teamId" value={team.id}/><button className="secondary">Archive team</button></form>}</details>)}</div>
    </section>

    <section className="card"><h2>Roster</h2><p className="muted">Participants can exist without app accounts and can be moved between teams.</p>
      <form action={addParticipant} className="grid"><input type="hidden" name="eventId" value={event.id}/><label>Display name<input name="displayName" required/></label><label>Optional external key<input name="externalKey" placeholder="Employee ID / source ID"/></label><label>Initial team<select name="teamId" defaultValue=""><option value="">Unassigned</option>{activeTeams.map((team)=><option key={team.id} value={team.id}>{team.name}</option>)}</select></label><label>Optional role<input name="roleKey" placeholder="captain / member / scorer ..."/></label><div className="form-actions"><button>Add participant</button></div></form>
      <div className="table-wrap"><table><thead><tr><th>Participant</th><th>External key</th><th>Current team</th><th>Assign</th></tr></thead><tbody>{event.participants.map((participant) => { const membership = participant.teamMemberships[0]; return <tr key={participant.id}><td>{participant.displayName || participant.person.displayName}</td><td><code>{participant.person.externalKey || "—"}</code></td><td>{membership?.team.name || "Unassigned"}</td><td><form action={assignParticipantTeam} className="row compact-form"><input type="hidden" name="eventId" value={event.id}/><input type="hidden" name="eventParticipantId" value={participant.id}/><select name="teamId" defaultValue={membership?.teamId ?? ""}><option value="">Unassigned</option>{activeTeams.map((team)=><option key={team.id} value={team.id}>{team.name}</option>)}</select><input name="roleKey" defaultValue={membership?.roleKey ?? ""} placeholder="role"/><button className="secondary">Assign</button></form></td></tr>})}</tbody></table></div>
    </section>
  </main>;
}
