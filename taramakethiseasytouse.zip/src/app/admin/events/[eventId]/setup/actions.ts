"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { EventBrandingConfigSchema, EventConfigSchema } from "@/schemas/event";
import { MachineKeySchema, TechnicalLimits } from "@/schemas/shared";
import { getCurrentUser } from "@/server/auth/session";
import { requireEventCapability } from "@/server/permissions/capabilities";
import { EventService } from "@/server/services/event-service";
import { RosterService } from "@/server/services/roster-service";
import { getPrisma } from "@/lib/prisma";
import { zonedLocalToUtc } from "@/lib/timezone";

async function userOrLogin() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}
const text = (form: FormData, key: string) => String(form.get(key) ?? "").trim();
const optional = (form: FormData, key: string) => text(form, key) || undefined;
const checked = (form: FormData, key: string) => form.get(key) === "on";

export async function updateEventDetails(formData: FormData) {
  const user = await userOrLogin();
  const eventId = text(formData, "eventId");
  await requireEventCapability(user.id, eventId, "event.configure");
  const timezone = text(formData, "timezone") || "Asia/Manila";
  await new EventService().updateDetails({
    eventId,
    name: text(formData, "name"),
    shortName: optional(formData, "shortName"),
    slug: MachineKeySchema.parse(text(formData, "slug")),
    timezone,
    startsAt: zonedLocalToUtc(text(formData, "startsAt"), timezone),
    endsAt: zonedLocalToUtc(text(formData, "endsAt"), timezone),
    actorUserId: user.id,
  });
  revalidatePath(`/admin/events/${eventId}`);
  revalidatePath(`/admin/events/${eventId}/setup`);
}

export async function updateEventConfiguration(formData: FormData) {
  const user = await userOrLogin();
  const eventId = text(formData, "eventId");
  await requireEventCapability(user.id, eventId, "event.configure");
  const topOnlyRaw = text(formData, "topOnly");
  const retentionRaw = text(formData, "retentionDays");
  const config = EventConfigSchema.parse({
    schemaVersion: 1,
    terminology: {
      team: text(formData, "termTeam"), participant: text(formData, "termParticipant"), station: text(formData, "termStation"), marshal: text(formData, "termMarshal"), points: text(formData, "termPoints"),
    },
    participation: { accountRequirement: text(formData, "accountRequirement"), deviceMode: text(formData, "deviceMode"), allowLateJoin: checked(formData, "allowLateJoin") },
    leaderboard: { enabled: checked(formData, "leaderboardEnabled"), visibility: text(formData, "leaderboardVisibility"), mode: text(formData, "leaderboardMode"), ...(topOnlyRaw ? { topOnly: Number(topOnlyRaw) } : {}), hideExactScores: checked(formData, "hideExactScores") },
    privacy: { eventVisibility: text(formData, "eventVisibility"), participantNameVisibility: text(formData, "participantNameVisibility"), mediaVisibility: text(formData, "mediaVisibility"), ...(retentionRaw ? { retentionDays: Number(retentionRaw) } : {}) },
    timing: { enforceSchedule: checked(formData, "enforceSchedule"), allowEarlyCheckInMinutes: Number(text(formData, "allowEarlyCheckInMinutes") || 0), allowLateJoin: checked(formData, "timingAllowLateJoin") },
    featureFlags: {},
  });
  await new EventService().updateConfiguration({ eventId, config, actorUserId: user.id });
  revalidatePath(`/admin/events/${eventId}/setup`);
}

export async function updateEventBranding(formData: FormData) {
  const user = await userOrLogin();
  const eventId = text(formData, "eventId");
  await requireEventCapability(user.id, eventId, "event.configure");
  const themeTokens = Object.fromEntries([
    ["accent", optional(formData, "accent")], ["background", optional(formData, "background")], ["surface", optional(formData, "surface")], ["text", optional(formData, "text")],
  ].filter((entry): entry is [string, string] => Boolean(entry[1])));
  const branding = EventBrandingConfigSchema.parse({
    logoAssetId: optional(formData, "logoAssetId"), coverAssetId: optional(formData, "coverAssetId"), teamColorUsage: text(formData, "teamColorUsage") || undefined, ...(Object.keys(themeTokens).length ? { themeTokens } : {}),
  });
  await new EventService().updateBranding({ eventId, branding, actorUserId: user.id });
  revalidatePath(`/admin/events/${eventId}/setup`);
}

export async function createTeam(formData: FormData) {
  const user = await userOrLogin();
  const eventId = text(formData, "eventId");
  await requireEventCapability(user.id, eventId, "teams.manage");
  await new EventService().addTeam({ eventId, machineKey: MachineKeySchema.parse(text(formData, "machineKey")), name: text(formData, "name"), abbreviation: optional(formData, "abbreviation"), colorToken: optional(formData, "colorToken"), logoAssetId: optional(formData, "logoAssetId"), teamCode: optional(formData, "teamCode"), actorUserId: user.id });
  revalidatePath(`/admin/events/${eventId}/setup`);
}

export async function bulkCreateTeams(formData: FormData) {
  const user = await userOrLogin();
  const eventId = text(formData, "eventId");
  await requireEventCapability(user.id, eventId, "teams.manage");
  const count = Number(text(formData, "count"));
  if (!Number.isInteger(count) || count < 1 || count > TechnicalLimits.maxTeamsPerBulkOperation) throw new Error(`Team count must be between 1 and ${TechnicalLimits.maxTeamsPerBulkOperation}`);
  const namePrefix = text(formData, "namePrefix") || "Team";
  const keyPrefix = MachineKeySchema.parse(text(formData, "keyPrefix") || "team");
  const start = Number(text(formData, "startNumber") || 1);
  if (!Number.isInteger(start) || start < 0) throw new Error("Start number must be a non-negative integer");
  const service = new EventService();
  for (let index = 0; index < count; index += 1) {
    const number = start + index;
    await service.addTeam({ eventId, machineKey: MachineKeySchema.parse(`${keyPrefix}-${number}`), name: `${namePrefix} ${number}`, actorUserId: user.id });
  }
  revalidatePath(`/admin/events/${eventId}/setup`);
}

export async function updateTeam(formData: FormData) {
  const user = await userOrLogin();
  const eventId = text(formData, "eventId");
  await requireEventCapability(user.id, eventId, "teams.manage");
  await new EventService().updateTeam({ eventId, teamId: text(formData, "teamId"), name: text(formData, "name"), abbreviation: optional(formData, "abbreviation"), colorToken: optional(formData, "colorToken"), logoAssetId: optional(formData, "logoAssetId"), teamCode: optional(formData, "teamCode"), actorUserId: user.id });
  revalidatePath(`/admin/events/${eventId}/setup`);
}

export async function archiveTeam(formData: FormData) {
  const user = await userOrLogin();
  const eventId = text(formData, "eventId");
  await requireEventCapability(user.id, eventId, "teams.manage");
  await new EventService().archiveTeam({ eventId, teamId: text(formData, "teamId"), actorUserId: user.id });
  revalidatePath(`/admin/events/${eventId}/setup`);
}

export async function addParticipant(formData: FormData) {
  const user = await userOrLogin();
  const eventId = text(formData, "eventId");
  await requireEventCapability(user.id, eventId, "roster.manage");
  await new RosterService().addParticipant({ eventId, displayName: text(formData, "displayName"), externalKey: optional(formData, "externalKey"), teamId: optional(formData, "teamId"), roleKey: optional(formData, "roleKey"), actorUserId: user.id });
  revalidatePath(`/admin/events/${eventId}/setup`);
}

export async function assignParticipantTeam(formData: FormData) {
  const user = await userOrLogin();
  const eventId = text(formData, "eventId");
  await requireEventCapability(user.id, eventId, "roster.manage");
  await new RosterService().assignTeam({ eventId, eventParticipantId: text(formData, "eventParticipantId"), teamId: optional(formData, "teamId"), roleKey: optional(formData, "roleKey"), actorUserId: user.id });
  revalidatePath(`/admin/events/${eventId}/setup`);
}
