import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/server/auth/session";
import { getPrisma } from "@/lib/prisma";
import { createEvent } from "./actions";
import { hasPlatformCapability } from "@/server/permissions/capabilities";
import { signOut } from "@/app/login/actions";

type EventListItem = { id: string; name: string; slug: string; state: string };

export default async function AdminPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const [events, canCreate, canSecurity] = await Promise.all([
    getPrisma().event.findMany({ where: { roles: { some: { assignments: { some: { userAccountId: user.id } } } } }, orderBy: { createdAt: "desc" } }),
    hasPlatformCapability(user.id, "events.create"),
    hasPlatformCapability(user.id, "security.manage"),
  ]);
  const eventList = events as EventListItem[];
  const activeCount = eventList.filter((event) => ["READY", "LIVE", "PAUSED"].includes(event.state)).length;
  return <main>
    <div className="page-heading organizer-heading"><div><div className="eyebrow">Organizer workspace</div><h1>Events</h1><p className="muted">Build, rehearse and operate reusable team-building events.</p></div><div className="row"><span className="user-chip">{user.name}</span>{canSecurity && <Link className="button secondary" href="/admin/security">Security & privacy</Link>}<form action={signOut}><button className="secondary">Sign out</button></form></div></div>
    <div className="stats-grid compact-stats"><div className="stat"><strong>{eventList.length}</strong><span>accessible events</span></div><div className="stat"><strong>{activeCount}</strong><span>ready / live</span></div></div>
    {canCreate && <section className="card create-event-card"><div className="section-heading"><div><h2>Create event</h2><p className="muted">Start with a clean reusable workspace. Activities and operations stay configurable.</p></div></div><form action={createEvent} className="grid"><label>Event name<input name="name" required placeholder="MPW Team Building 2027"/></label><label>URL slug<input name="slug" required pattern="[a-z0-9-]+" placeholder="mpw-team-building-2027"/></label><div className="form-actions"><button>Create event</button></div></form></section>}
    <section><div className="section-heading"><div><h2>Your events</h2><p className="muted">Open a workspace to configure or operate it.</p></div></div>{eventList.length === 0 ? <div className="empty-state"><strong>No events yet</strong><span>Create your first reusable event workspace above.</span></div> : <div className="event-card-grid">{eventList.map((event) => <article className="event-card" key={event.id}><div className="event-card-top"><span className={`status-dot state-${event.state.toLowerCase()}`} aria-hidden="true"/><span className="badge">{event.state}</span></div><div><h3>{event.name}</h3><code>{event.slug}</code></div><div className="event-card-actions"><Link className="button" href={`/admin/events/${event.id}`}>Open workspace</Link><Link className="text-link" href={`/e/${event.slug}`}>Participant view →</Link></div></article>)}</div>}</section>
  </main>;
}
