"use server";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/server/auth/session";
import { EventService } from "@/server/services/event-service";
import { requirePlatformCapability } from "@/server/permissions/capabilities";
import { getPrisma } from "@/lib/prisma";
import { MachineKeySchema } from "@/schemas/shared";

export async function createEvent(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  await requirePlatformCapability(user.id, "events.create");
  const organization = await getPrisma().organization.findFirstOrThrow();
  const name = String(formData.get("name") || "").trim();
  if (!name) throw new Error("Event name is required");
  const slug = MachineKeySchema.parse(String(formData.get("slug") || "").trim());
  const event = await new EventService().create({ organizationId: organization.id, name, slug, actorUserId: user.id });
  redirect(`/admin/events/${event.id}`);
}
